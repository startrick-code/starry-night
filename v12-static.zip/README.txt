Starry Night V1.2 art refinement; commit e15a2de0276ba8f16c01ccabdbb060d7af609ddb
Serve this directory via HTTP(S); relative assets support GitHub Pages.
This is a review build: technical checks passed, artistic acceptance is pending.
No runtime remote textures, backend or account required.
